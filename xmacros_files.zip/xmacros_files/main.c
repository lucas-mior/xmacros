/*
 * Copyright (C) 2025 Mior, Lucas;
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the*License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stddef.h>
#include <limits.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "assert.c"

#define STRUCT_NAME NumberStruct
#define STRUCT_FIELDS                                                          \
    X(char, ic)                                                                \
    X(uchar, uc)                                                               \
    X(signed short, is)                                                        \
    X(ushort, us)                                                              \
    X(int, ii)                                                                 \
    X(uint, ui)                                                                \
    X(long, il)                                                                \
    X(ulong, ul)                                                               \
    X(float, f, 10)                                                            \
    X(double, d)
#include "xstructs.c"

#define STRUCT_NAME SmallStruct
#define STRUCT_FIELDS                                                          \
    X(char *, string)                                                          \
    X(NumberStruct, number_struct)
#include "xstructs.c"

#define STRUCT_NAME BigStruct
#define STRUCT_FIELDS                                                          \
    X(long, l)                                                                 \
    X(SmallStruct *, small_struct)
#include "xstructs.c"

#define EXPAND_STRUCTS                                                         \
    STRUCT(SmallStruct)                                                        \
    STRUCT(NumberStruct)                                                       \
    STRUCT(BigStruct)
#include "fmt_functions.h"

#define ENUM_NAME WeekDay
#define ENUM_PREFIX_ WEEK_DAY_
#define ENUM_BITFLAGS 0
#define ENUM_FIELDS   \
    X(WEEK_DAY_SUNDAY, 0)      \
    X(WEEK_DAY_MONDAY)         \
    X(WEEK_DAY_TUESDAY, 10)    \
    X(WEEK_DAY_WEDNESDAY)      \
    X(WEEK_DAY_THURSDAY)       \
    X(WEEK_DAY_FRIDAY, 5)      \
    X(WEEK_DAY_SATURDAY, 20)
#include "xenums.c"

#define ENUM_NAME PowerOfTwo
#define ENUM_PREFIX_ POWER_OF2_
#define ENUM_BITFLAGS 1
#define ENUM_FIELDS \
    X(POWER_OF2_ONE)          \
    X(POWER_OF2_TWO)          \
    X(POWER_OF2_FOUR)         \
    X(POWER_OF2_EIGHT)        \
    X(POWER_OF2_SIXTEEN)      \
    X(POWER_OF2_THIRTY2)      \
    X(POWER_OF2_SIXTY4)
#include "xenums.c"

#define ENUM_NAME Flags
#define ENUM_PREFIX_ FLAG_
#define ENUM_BITFLAGS 1
#define ENUM_FIELDS \
    X(FLAG_READ) \
    X(FLAG_WRITE) \
    X(FLAG_EXEC) \
    X(FLAG_READ_WRITE, FLAG_READ|FLAG_WRITE) \
    X(FLAG_READ_EXEC)
#include "xenums.c"

int
main(void) {
    {
        enum Flags flag = FLAG_READ_WRITE;
        ASSERT_EQUAL(FLAG_str(flag), "FLAG_READ|FLAG_WRITE|FLAG_READ_WRITE");
        ASSERT_EQUAL(FLAG_str(FLAG_READ_EXEC), "FLAG_READ_EXEC");
        ASSERT_EQUAL(FLAG_READ_EXEC, 1 << 4);
    }

    {
        char *str_ptr;

        ASSERT_EQUAL(WEEK_DAY_str(WEEK_DAY_SUNDAY), "WEEK_DAY_SUNDAY");
        ASSERT_EQUAL(WEEK_DAY_str(WEEK_DAY_MONDAY), "WEEK_DAY_MONDAY");
        ASSERT_EQUAL(WEEK_DAY_str(WEEK_DAY_SATURDAY), "WEEK_DAY_SATURDAY");
        ASSERT_EQUAL(WEEK_DAY_str(999), "Unknown value");

        if ((str_ptr = POWER_OF2_str(POWER_OF2_ONE))) {
            ASSERT_EQUAL(str_ptr, "POWER_OF2_ONE");
            free2(str_ptr, strlen32(str_ptr) + 1);
        }

        if ((str_ptr = POWER_OF2_str(POWER_OF2_ONE
                                     | POWER_OF2_FOUR
                                     | POWER_OF2_SIXTY4))) {
            ASSERT_EQUAL(str_ptr, "POWER_OF2_ONE|POWER_OF2_FOUR|POWER_OF2_SIXTY4");
            free2(str_ptr, strlen32(str_ptr) + 1);
        }

        ASSERT_EQUAL(POWER_OF2_str(0), "NONE");
    }

    {
        size_t expected_small_size = sizeof(char *) + sizeof(NumberStruct);

        ASSERT_EQUAL(NumberStruct_fmt.num_members, 11);
        ASSERT_EQUAL(SmallStruct_fmt.num_members, 2);
        ASSERT_EQUAL(BigStruct_fmt.num_members, 2);

        ASSERT_EQUAL(NumberStruct_fmt.struct_name, "NumberStruct");
        ASSERT_EQUAL(SmallStruct_fmt.names[0], "string");
        ASSERT_EQUAL(SmallStruct_fmt.types[0], "char *");

        ASSERT_EQUAL(SmallStruct_fmt.packed_size, expected_small_size);
    }

    {
        NumberStruct original_num = {
            .ic = 'c',
            .uc = 'd',
            .is = SHRT_MAX,
            .us = USHRT_MAX,
            .ii = INT_MAX,
            .ui = UINT_MAX,
            .il = LONG_MAX,
            .ul = ULONG_MAX,
            .f = {0.0f, 1.1f, 2.2f, 3.3f, 4.4f, 5.5f, 6.6f, 7.7f, 8.8f, 9.9f},
            .d = 0.5,
        };
        NumberStruct restored_num;
        SmallStruct original_small = {
            .string = "reflection test",
            .number_struct = original_num
        };
        SmallStruct restored_small;
        BigStruct big_val = {
            .l = 123456789,
            .small_struct = &original_small
        };
        BigStruct *p_big = &big_val;
        uchar *n_buf;
        uchar *s_buf;

        if ((n_buf = malloc2(NumberStruct_fmt.packed_size)) == NULL) {
            return EXIT_FAILURE;
        }
        NumberStruct_pack(&original_num, n_buf);
        NumberStruct_unpack(n_buf, &restored_num);

        ASSERT_EQUAL(original_num.ic, restored_num.ic);
        ASSERT_EQUAL(original_num.is, restored_num.is);
        ASSERT_EQUAL(original_num.ui, restored_num.ui);

        for (int32 i = 0; i < 10; i += 1) {
            ASSERT_EQUAL(original_num.f[i], restored_num.f[i]);
        }

        if ((s_buf = malloc2(SmallStruct_fmt.packed_size)) == NULL) {
            free2(n_buf, NumberStruct_fmt.packed_size);
            return EXIT_FAILURE;
        }
        SmallStruct_pack(&original_small, s_buf);
        SmallStruct_unpack(s_buf, &restored_small);

        ASSERT_EQUAL(original_small.string, restored_small.string);
        ASSERT_EQUAL(original_small.number_struct.ii,
                     restored_small.number_struct.ii);

        for (int32 i = 0; i < 10; i += 1) {
            ASSERT_EQUAL(original_small.number_struct.f[i],
                         restored_small.number_struct.f[i]);
        }

        printf("--- Printing BigStruct (Includes Pointer to SmallStruct) ---\n");
        STRUCT_PRINT(&big_val);

        printf("--- Printing BigStruct via Pointer ---\n");
        STRUCT_PRINT(p_big);

        printf("--- Printing Restored NumberStruct ---\n");
        STRUCT_PRINT(&restored_num);

        free2(n_buf, NumberStruct_fmt.packed_size);
        free2(s_buf, SmallStruct_fmt.packed_size);
        PRINT(original_num.f[0]);
    }

    printf("\nmain.c: All tests passed.\n");
    return EXIT_SUCCESS;
}
